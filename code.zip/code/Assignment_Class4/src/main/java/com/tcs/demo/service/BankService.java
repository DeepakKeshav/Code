package com.tcs.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tcs.demo.exception.RecordNotFoundException;
import com.tcs.demo.model.CustomerEntity;
import com.tcs.demo.repository.CustomerRepo;

@Service
public class BankService {
	
	 @Autowired
	 CustomerRepo repository;

	public List<CustomerEntity> getAllEmployees() {
		// TODO Auto-generated method stub
		 List<CustomerEntity> employeeList = repository.findAll();
         
	        if(employeeList.size() > 0) {
	            return employeeList;
	        } else {
	            return new ArrayList<CustomerEntity>();
	        }
	}
	
	
	 public CustomerEntity getEmployeeById(Long id) throws RecordNotFoundException
	    {
	        Optional<CustomerEntity> employee = repository.findById(id);
	         
	        if(employee.isPresent()) {
	            return employee.get();
	        } else {
	            throw new RecordNotFoundException("No employee record exist for given id");
	        }
	    }
	     
	    public CustomerEntity createOrUpdateEmployee(CustomerEntity entity) throws RecordNotFoundException
	    {
	        Optional<CustomerEntity> employee = repository.findById(entity.getId());
	         
	        if(employee.isPresent())
	        {
	        	CustomerEntity newEntity = employee.get();
	            newEntity.setName(entity.getName());
	            newEntity.setAge(entity.getAge());
	            newEntity.setAddress(entity.getAddress());
	            newEntity.setAccounttype(entity.getAccounttype());
	 
	            newEntity = repository.save(newEntity);
	             
	            return newEntity;
	        } else {
	            entity = repository.save(entity);
	             
	            return entity;
	        }
	    }
	     
	    public void deleteEmployeeById(Long id) throws RecordNotFoundException
	    {
	        Optional<CustomerEntity> employee = repository.findById(id);
	         
	        if(employee.isPresent())
	        {
	            repository.deleteById(id);
	        } else {
	            throw new RecordNotFoundException("No employee record exist for given id");
	        }
	    }
	

}
