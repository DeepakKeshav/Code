package com.tcs.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentClass4Application {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentClass4Application.class, args);
	}

}
