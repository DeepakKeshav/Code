INSERT INTO 
	TBL_CUSTOMERS (name,age,address,account_type) 
VALUES
  	('spiderman', 25, '626 avanger dr texas,USA','savings'),
  	('iranman', 30, '627 avanger dr texas,USA','checking'),
  	('thanos', 25, '626 ham dr texas,USA','savings');