package com.tcs.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssignmentClass3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
