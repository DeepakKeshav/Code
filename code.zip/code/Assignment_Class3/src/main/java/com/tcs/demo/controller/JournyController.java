package com.tcs.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.demo.exception.RecordNotFoundException;
import com.tcs.demo.model.HotelEntity;
import com.tcs.demo.service.HotelService;

@RestController
@RequestMapping("/hotels")
public class  JournyController {
	
	@Autowired
	HotelService service;
	
	@GetMapping
	public ResponseEntity<List<HotelEntity>> getAllCustomers( @RequestParam(defaultValue = "0", name="page") Integer pageNo, 
            @RequestParam(defaultValue = "10",name="size") Integer pageSize){
		
        List<HotelEntity> list = service.getAllHotels(pageNo,pageSize);
        
        return new ResponseEntity<List<HotelEntity>>(list, new HttpHeaders(), HttpStatus.OK);

	}
		 
	    @PutMapping
	    public ResponseEntity<HotelEntity> createOrUpdateEmployee(HotelEntity hotel)
	                                                    throws RecordNotFoundException {
	    	HotelEntity updated = service.Update(hotel);
	        return new ResponseEntity<HotelEntity>(updated, new HttpHeaders(), HttpStatus.NO_CONTENT);
	    }
	 
	   
	
	

}
