package com.tcs.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.tcs.demo.exception.RecordNotFoundException;
import com.tcs.demo.model.HotelEntity;
import com.tcs.demo.repository.HotelsRepo;

@Service
public class HotelService {
	
	 @Autowired
	 HotelsRepo repository;

	public List<HotelEntity> getAllHotels(int pageno, int pagesize) {
		// TODO Auto-generated method stub
		 
	        Pageable paging = PageRequest.of(pageno, pagesize,Sort.by("rating"));
	        
	        Page<HotelEntity> pagedResult = repository.findAll(paging);
	        
	        if(pagedResult.hasContent()) {
	            return pagedResult.getContent();
	        } else {
	            return new ArrayList<HotelEntity>();
	        }
	}
	
	     
	    public HotelEntity Update(HotelEntity entity) throws RecordNotFoundException
	    {
	        Optional<HotelEntity> hotel = repository.findById(entity.getId());
	         
	        if(hotel.isPresent())
	        {
	        	HotelEntity newEntity = hotel.get();
	            newEntity.setName(entity.getName());
	            newEntity.setDesc(entity.getDesc());
	            newEntity.setCity(entity.getCity());
	            newEntity.setRating(entity.getRating());
	 
	            newEntity = repository.save(newEntity);
	             
	            return newEntity;
	        } else {
	            entity = repository.save(entity);
	             
	            return entity;
	        }
	    }
	     
	   
	

}
