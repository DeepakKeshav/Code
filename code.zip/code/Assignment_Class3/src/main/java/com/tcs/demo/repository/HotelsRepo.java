package com.tcs.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tcs.demo.model.HotelEntity;

@Repository
public interface HotelsRepo extends JpaRepository<HotelEntity, Long> {
	

}
