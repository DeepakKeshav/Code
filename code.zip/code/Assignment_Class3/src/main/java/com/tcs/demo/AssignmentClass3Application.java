package com.tcs.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentClass3Application {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentClass3Application.class, args);
	}

}
