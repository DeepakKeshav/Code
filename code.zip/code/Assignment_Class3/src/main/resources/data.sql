INSERT INTO 
	TBL_HOTELS (name,description,city,rating) 
VALUES
  	('JourneyB1', 'A clean and basic hotel', 'Bangalore',1),
  	('JourneyB2', 'A clean and basic hotel', 'Bangalore',2),
  	('JourneyB3', 'A clean and basic hotel', 'Bangalore',3),
  	('JourneyB4', 'A clean and basic hotel', 'Bangalore',4),
  	('JourneyB5', 'A clean and basic hotel', 'Bangalore',5),
	('JourneyB6', 'A clean and basic hotel', 'Bangalore',6),
	('JourneyB7', 'A clean and basic hotel', 'Bangalore',7),
	('JourneyB8', 'A clean and basic hotel', 'Bangalore',8),
	('JourneyB9', 'A clean and basic hotel', 'Bangalore',9),
	('JourneyB10', 'A clean and basic hotel', 'Bangalore',10),
	('JourneyB11', 'A clean and basic hotel', 'Bangalore',11),
	('JourneyB12', 'A clean and basic hotel', 'Bangalore',12),
	('JourneyB13', 'A clean and basic hotel', 'Bangalore',13),
	('JourneyB14', 'A clean and basic hotel', 'Bangalore',14),
	('JourneyB15', 'A clean and basic hotel', 'Bangalore',15),
	('JourneyB14', 'A clean and basic hotel', 'Bangalore',16);